document.addEventListener('DOMContentLoaded', async () => {
    await displayCandyItems();
  
    const addCandyForm = document.getElementById('add-candy-form');
    addCandyForm.addEventListener('submit', addCandyItem);
  });
  
  async function displayCandyItems() {
    const candyList = document.getElementById('candy-list');
    candyList.innerHTML = '';
  
    const candyItems = await getCandyItems();
  
    if (candyItems.length === 0) {
      candyList.innerHTML = '<p>No candy items found.</p>';
      return;
    }
  
    candyItems.forEach((candy) => {
      const candyItem = document.createElement('div');
      candyItem.className = 'candy-item';
  
      const name = document.createElement('h3');
      name.textContent = candy.name;
      candyItem.appendChild(name);
  
      const description = document.createElement('p');
      description.textContent = candy.description;
      candyItem.appendChild(description);
  
      const price = document.createElement('p');
      price.textContent = 'Price: ' + candy.price;
      candyItem.appendChild(price);
  
      const quantity = document.createElement('p');
      quantity.textContent = 'Quantity: ' + candy.quantity;
      candyItem.appendChild(quantity);
  
      const buyButtons = document.createElement('div');
      buyButtons.className = 'buy-buttons';
  
      for (let i = 1; i <= 3; i++) {
        const buyButton = document.createElement('button');
        buyButton.textContent = 'Buy ' + i;
        buyButton.addEventListener('click', async () => await decreaseQuantity(candy.name, i));
        buyButtons.appendChild(buyButton);
      }
  
      candyItem.appendChild(buyButtons);
  
      candyList.appendChild(candyItem);
    });
  }
  
  async function getCandyItems() {
    return new Promise((resolve, reject) => {
      try {
        const candyItemsString = localStorage.getItem('candyItems');
        const candyItems = candyItemsString ? JSON.parse(candyItemsString) : [];
        resolve(candyItems);
      } catch (error) {
        reject(error);
      }
    });
  }
  
  async function setCandyItems(candyItems) {
    return new Promise((resolve, reject) => {
      try {
        localStorage.setItem('candyItems', JSON.stringify(candyItems));
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  }
  
  async function addCandyItem(event) {
    event.preventDefault();
  
    const candyName = document.getElementById('candy-name').value;
    const candyDescription = document.getElementById('candy-description').value;
    const candyPrice = document.getElementById('candy-price').value;
    const candyQuantity = document.getElementById('candy-quantity').value;
  
    const candyItem = {
      name: candyName,
      description: candyDescription,
      price: candyPrice,
      quantity: candyQuantity
    };
  
    try {
      const candyItems = await getCandyItems();
      candyItems.push(candyItem);
      await setCandyItems(candyItems);
  
      await displayCandyItems();
      addCandyForm.reset();
    } catch (error) {
      console.error('Error adding candy item:', error);
    }
  }
  
  async function decreaseQuantity(candyName, amount) {
    try {
      const candyItems = await getCandyItems();
      const candyItem = candyItems.find((candy) => candy.name === candyName);
  
      if (candyItem) {
        candyItem.quantity -= amount;
  
        if (candyItem.quantity <= 0) {
          candyItem.quantity = 'Quantity is low';
        }
  
        await setCandyItems(candyItems);
        await displayCandyItems();
      }
    }
    catch(error)
    {
        console.error('error decreasing quantity:',error);
    }
}
